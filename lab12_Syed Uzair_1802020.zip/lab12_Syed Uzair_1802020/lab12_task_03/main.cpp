#include <iostream>

using namespace std;

int const size = 10;

void insert(int *array, int n)
{
    int i;
    for(i=n;i>0;i--)
    {
        if(array[i]<array[i-1])
        {
            swap(array[i],array[i-1]);
        }
        else
            break;
    }
}

void insertionsort(int *array, int n)
{
    int i;
    for(i=0;i<=n;i++)
    {
        insert(array,i+1);
    }
}

void display(int *array)
{
    int i;
    for(i=0;i<size;i++)
    {
        cout << array[i] << endl;
    }
}

int main()
{
    int array[size]={5,2,1,4,3,7,8,6,9,0};
    insertionsort(array,size-1);
    display(array);
    return 0;
}
