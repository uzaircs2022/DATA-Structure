#include <iostream>

using namespace std;


int const size = 10;

void display(int *array)
{
    int i;
    for(i=0; i<size; i++)
    {
        cout << array[i] << endl;
    }
}

int merge(int *array, int *array1,int *array2,int n,int first,int second)
{
    int z=0,i=0,j=0,x;
    for(x=0; x<=n; x++)
    {
        if(array[i]<array1[j])
        {
            if(i==first)
            {
                for(int g=j; g<6; g++)
                {
                    array2[z]=array1[g];
                    z++;
                }
                break;
            }
            array2[z]=array[i];
            i++;
            z++;
        }
        else
        {
            if(j==second)
            {
                for(int g=i; g<6; g++)
                {
                    array2[z]=array1[g];
                    z++;
                }
                break;
            }
            array2[z]=array1[j];
            j++;
            z++;
        }
    }
  //  display(array2);
}


int main()
{
    int array2[size];
    int array[5]= {100,200,300,400,500};
    int array1[5]= {150,270,308,906,1110};

    merge(array,array1,array2,size-1,5,5);
      display(array2);
    return 0;
}
