#include <iostream>

using namespace std;

const int size=10;

class heap
{
private:
    int i=0,j=1,d;
    int check;
public:

    int insert(int a, int *array1)
    {
        if(j==1)
        {
            array1[i]=a;
        }
        if(j==2)
        {
            if(array1[i] < a)
            {
                swap(a,array1[i]);
            }
            array1[(2*i)+1]=a;
            check=i;
            while(array1[check] > array1[(check-1)/2])
            {
                swap(array1[check],array1[(check-1)/2]);
                check=(check-1)/2;
            }
            if((2*i)+1==size)
            {
                cout << "HEAP HAS BEEN Filled COMPLETELY" << endl;
                j==2;
                return 0;
            }
        }
        if(j==3)
        {
            if(array1[i] < a)
            {
                swap(a,array1[i]);
            }
            array1[(2*i)+2]=a;
            check=i;
            while(array1[i] > array1[(i-1)/2])
            {
                swap(array1[i],array1[(i-1)/2]);
                check=(check-1)/2;
            }
        }

        if(j==3)
        {
            j=1;
            i++;
        }
        j++;
    }// end of insert function

    void display1(int *array1)
    {
        for(i=0; i<size; i++)
        {
            cout << array1[i] << endl;
        }
    } // END OF DISPLAY FUNCTION

    int max1(int a, int b)
    {
        if(a<b)
            return b;
        else
            return a;
    }

    int del(int *array1,int size1)
    {
        int x=0,check1,a;
        swap(array1[size1-1],array1[0]);
        a=array1[size-1];
        array1[size-1] = 0;
        while(x < size1)
        {
            check1=max1(array1[(2*x)+1],array1[(2*x)+2]);
            if(check1==array1[(2*x)+1] && array1[x] < array1[(2*x)+1])
            {
                swap(array1[(2*x)+1],array1[x]);
            }
            else if(check1==array1[(2*x)+2] && array1[x] < array1[(2*x)+2])
            {
                swap(array1[(2*x)+2],array1[x]);
            }
            x++;
            if((2*x+1)==size1-1)
                return a;
        }
    } //END OF DEL FUNCTION



    void isheap()
    {
        int i,x=0;
        int array2[size];
        for(i=0; i<size; i++)
        {
            cout << "ENTER THE VALUE NO " << i << endl;
            cin >> array2[i];
        }
        while(true)
        {
            if(((2*x)+1) > size-1 || ((2*x)+2) > size-1)
            {
                break;
            }

            if(array2[x] >= array2[(2*x)+1] && array2[x] >= array2[(2*x)+2])
            {
                x++;
            }
            else
            {
                cout << "ITS NOT A HEAP" << endl;
                return;
            }

        }
        if(((2*x)+1)<=size-1)
        {
            if(array2[(2*x)+1]<=array2[x])
                cout << "ITS A HEAP" << endl;
            else
                cout << "its not a heap" << endl;
        }

    }// END OF IS HEAP FUNCTION

    void heap_sort(int *array,int *array1,int *array2,int size1)
    {
        for(int i=0; i<=size1; i++)
        {
            insert(array[i],array1);
        }
        for(int j=size1; j>=0; j--)
        {
            int a;
            a=del(array1,10);
            //cout << a << endl;
            array2[j] = a;
        }

    }

}; // END OF CLASS HEAP


int main()
{
    heap obj;
    int array1[size];
    int array2[size]={0};
    int array[size]= {11,2,3,4,5,6,0,8,9,10};
    obj.heap_sort(array,array1,array2,size-1);
   // obj.del(array1,10);
   obj.display1(array2);
    return 0;
}
