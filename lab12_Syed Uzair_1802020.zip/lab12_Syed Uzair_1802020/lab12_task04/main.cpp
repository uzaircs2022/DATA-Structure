#include <iostream>

using namespace std;

int const size = 10;

void movmin(int *array, int n, int j)
{
    int i,min=1000,index;
    for(i=j;i<=n;i++)
    {
            if(array[i]<min)
            {
                min=array[i];
                index=i;
            }
    }
    swap(array[j],array[index]);
}


void movminsort(int *array, int n)
{
    int i;
    for(i=0;i<=n;i++)
    {
        movmin(array,n,i);
    }
}

void display(int *array)
{
    int i;
    for(i=0;i<size;i++)
    {
        cout << array[i] << endl;
    }
}
int main()
{
    int array[size]={5,2,1,4,3,7,8,6,9,0};
    movminsort(array,size-1);
    display(array);
    return 0;
}
