#include <iostream>

using namespace std;

int const size = 10;

void movmin(int *array, int n)
{
    int i,min=1000,index;
    for(i=0;i<=n;i++)
    {
            if(array[i]<min)
            {
                min=array[i];
                index=i;
            }
    }
    swap(array[0],array[index]);
}

void display(int *array)
{
    int i;
    for(i=0;i<size;i++)
    {
        cout << array[i] << endl;
    }
}

int main()
{
     int array[size]={11,2,3,4,5,6,0,8,9,10};

    movmin(array,size-1);

    display(array);
    return 0;
}
