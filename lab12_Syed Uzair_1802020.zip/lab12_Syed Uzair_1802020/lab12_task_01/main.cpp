#include <iostream>

using namespace std;

int const size = 10;
void insert(int *array, int n)
{
    int i;
    for(i=n;i>0;i--)
    {
        if(array[i]<array[i-1])
        {
            swap(array[i],array[i-1]);
        }
        else
            break;
    }
}
void display(int *array)
{
    int i;
    for(i=0;i<size;i++)
    {
        cout << array[i] << endl;
    }
}

int main()
{

    int array[10]={1,2,3,4,5,6,7,8,9,0};
    insert(array,size-1);
    display(array);
    return 0;
}
