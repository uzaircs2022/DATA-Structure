#include <iostream>

using namespace std;

const int size = 10;

class node
{
private:
    int data;
    node *next;
public:
    node()
    {
        data=0;
        next=NULL;
    }
    void setdata(int a)
    {
        data = a;
    }
    void setnext(node* b)
    {
        next = b;
    }
    int getdata()
    {
        return data;
    }
    node* getnext()
    {
        return next;
    }
}; // end of first class

class linkedlist
{

    node *head[10];
public:
    linkedlist()
    {
        head[10]={NULL};
    }

      int hashfunction(int key)
    {
        return key%size;
    } // END OF FUNCTION


    void addatend(int a)
    {
        int index;
        index = hashfunction(a);
        node *n=new node();
        n->setdata(a);
        node *temp=head[index];
        if(head[index]==NULL)
        {
            head[index]=n;
        }
        else
        {
            while(temp->getnext()!= NULL)
            {
                temp=temp->getnext();
            }
            temp->setnext(n);
        }
    } //end of add at end

    void addatstart(int b)
    {
        int index;
        index = hashfunction(b);
        node*n=new node();
        n->setdata(b);
        node*temp=head[index];
        head[index]=n;
        n->setnext(temp);
    }// end of add at start

    void removefromstart()
    {
        int index;
        if(head[index]==NULL)
        {
         cout << "List Is Empty" << endl;
        }
        else
        head[index]=head[index]->getnext();

    }// end of remove from start

    void removefromend()
    {
        int index;
        node*temp=new node();
        temp=head[index];
        if(temp->getnext() == NULL)
        {
            removefromstart();
        }
        else
        {
            while(temp->getnext()->getnext()!= NULL )
            {
                temp=temp->getnext();
            }

            temp->setnext(NULL);

        }
    }// end of remove from end

    void removethevalue(int key)
    {
        int index;
        index = hashfunction(key);
        node*temp1=head[index];
        node*temp2=head[index];
        //temp1=head[index];
        //temp2=head[index];
        if(head[index]==NULL)
        {
            cout << "list is empty " << endl;
        }
        else
        {
        if(temp1->getdata()==key)
        {
            removefromstart();
        }
            else
        {
        while(temp1->getnext()->getdata() != key )
        {
            temp1=temp1->getnext();
        }
        if(temp1->getnext()->getnext()==NULL)
        {
            temp1->setnext(NULL);
        }
        else
        {   temp2=temp1;
            temp1->setnext(temp2->getnext()->getnext());
        }
        }
        }
    } // end of remove the value

    int getsize()
    {
        int index;
        int a=0;
        node*temp=new node();
        temp=head[index];
        while(temp->getnext()!=NULL)
        {
            a++;
            temp=temp->getnext();
        }
        return a+1;
    }// end of get size

    void removeatindex(int a)
    {
        int index;
        if(head[index]==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            int num=1,x;
            x=getsize();
            if(a>x)
            {
                cout << "Index is not correct" << endl;
            }
            else
            {
                node*temp1=new node();
                node*temp2=new node();
                temp1=head[index];
                temp2=head[index];
                if(a==1)
                {
                    removefromstart();
                }
                else
                {
                    while(num<a)
                    {
                        temp1=temp1->getnext();
                        //cout << num << endl;
                        num++;
                    }
                    num=1;
                    while(num<a-1)
                    {
                        temp2=temp2->getnext();
                         // cout << num << endl;
                        num++;
                    }
                    temp2->setnext(temp1->getnext());
                }
            }
        }
    }// end of remove at index

    void addnewvalue(int a, int b)
    {
        int index;
        node*namal=new node();
        namal=head[index];
        int num=1;
        int check;
        if(namal==NULL)
        {
            cout << "list is empty value will store in first index" << endl;
            addatstart(a);
        }
        else
        {
            if(b<=1)
            {
                addatstart(a);
            }
            else
            {
                //cout << "Enter the value you want to enter" << endl;
                //cin >> val;
                check=getsize();
                if(b>check)
                {
                    addatend(a);
                }
                node*temp1=new node();
                node*temp2=new node();
                node*n=new node();
                n->setdata(a);
                temp1=head[index];
                temp2=head[index];
                //num=1;
                while(num<b-1)
                {
                    temp2=temp2->getnext();
                    num++;
                }
                temp1=temp2->getnext();
                temp2->setnext(n);
                n->setnext(temp1);
            }
        }
    }// end of new value

    void getvalue(int b)
    {
        int index;
        int num=1,c;
        node*temp1=new node();
        temp1=head[index];
        c=getsize();
        if(b>c)
        {
            cout << "This index does not exist" << endl;
        }
        else
        {
            while(num<b)
            {
                temp1=temp1->getnext();
                num++;
            }
            cout << "The value of required Index is " << temp1->getdata() <<endl;;
        }
    } // end of get value

    void searchvalue(int b)
    {
        int index;
        index = hashfunction(b);
        int num=1,check,check1=0;
        node*temp=new node();
        temp=head[index];
       // check = getsize();
        //cout << check ;
        while(temp != NULL)
        {
            if(temp->getdata() == b)
            {
                cout << "The value is present " << endl;
               // cout << num <<endl;
                check1=1;
                break;
            }
            else
            {
                temp=temp->getnext();
                num++;
            }
        }

        if(check1==0)
        {
            cout << "Value doesnot exist" << endl;
        }
    }// end of search value


    void display()
    {
        int index = hashfunction(3);
        node *temp;
        temp=head[index];
        if(head[index]==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            while(temp->getnext() != NULL)
            {
                cout << temp->getdata() << endl;
                temp=temp->getnext();
            }
           cout << temp->getdata() << endl;
        }

    }// end of display function



   /* void insert(int key)
    {
        int index;
        index = hashfunction(key);
        array1[index]->addatstart(key);
    } // END OF INDERT FUNCTION


    void del(int key)
    {
        int index;
        index = hashfunction(key);
        array1[index]->removethevalue(key);
    } // END OF DEL FUNCTION

    void search1(int key)
    {
        int index;
        index = hashfunction(key);
        array1[index]->searchvalue(key);
    } // END OF SEARCH FUNCTION

    void display1(int a)
    {
        int index;
        index = hashfunction(a);
        cout << index;
        array1[index]->display();
    }
*/
};// end of second class

class chaining
{
    linkedlist *array1[size];

public:

};// END OF CHAIN CLASS
int main()
{
    int loop=0,choice;
    linkedlist obj;
    while(loop==0)
    {
        cout << "PRESS 1 TO INSERT A VALUE" << endl;
        cout << "PRESS 2 TO DELETE A VALUE" << endl;
        cout << "PRESS 3 TO search A VALUE" << endl;
        cout << "PRESS 4 TO DISPLAY" << endl;
        cin >> choice;

        if(choice==1)
        {
            int a;
            cout << "ENTER THE VALUE YOU WANT TO INSERT" << endl;
            cin >> a;
            obj.addatstart(a);
            cout << "PRESS 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> loop;
        }
        if(choice==2)
        {
            int a;
            cout << "ENTER THE VALUE YOU WANT TO DELETE" << endl;
            cin >> a;
            obj.removethevalue(a);
            cout << "PRESS 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> loop;
        }
        if(choice==3)
        {
            int a;
            cout << "ENTER THE VALUE YOU WANT TO SEARCH" << endl;
            cin >> a;
            obj.searchvalue(a);
            cout << "PRESS 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> loop;
        }
        if(choice==4)
        {
            //int a;
          //  cin >> a;
            obj.display();
            cout << "PRESS 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> loop;
        }




    }// END OF LOOP


    cout << "Hello world!" << endl;
    return 0;
}
