#include <iostream>

using namespace std;
const int size=10;
class heap
{
private:
    int array1[size];
    int i=0,j=1,d;
    int check;
public:

    int insert(int a)
    {
        if(j==1)
        {
            array1[i]=a;
        }
        if(j==2)
        {
            if(array1[i] < a)
            {
                swap(a,array1[i]);
            }
            array1[(2*i)+1]=a;
            check=i;
            while(array1[check] > array1[(check-1)/2])
            {
                swap(array1[check],array1[(check-1)/2]);
                check=(check-1)/2;
            }
            if((2*i)+1==size)
            {
                cout << "HEAP HAS BEEN Filled COMPLETELY" << endl;
                j==2;
                return 0;
            }
        }
        if(j==3)
        {
            if(array1[i] < a)
            {
                swap(a,array1[i]);
            }
            array1[(2*i)+2]=a;
            check=i;
            while(array1[i] > array1[(i-1)/2])
            {
                swap(array1[i],array1[(i-1)/2]);
                check=(check-1)/2;
            }
        }

        if(j==3)
        {
            j=1;
            i++;
        }
        j++;
    }// end of insert function

    void display1()
    {
        for(i=0; i<size; i++)
        {
            cout << array1[i] << endl;
        }
    } // END OF DISPLAY FUNCTION

    int max1(int a, int b)
    {
        if(a<b)
            return b;
        else
            return a;
    }

    void del()
    {
        int x=0,check1;
        swap(array1[size-1],array1[0]);
        array1[size-1]=0;
        while(x < size)
        {
            check1=max1(array1[(2*x)+1],array1[(2*x)+2]);
            if(check1==array1[(2*x)+1] && array1[x] < array1[(2*x)+1])
            {
                swap(array1[(2*x)+1],array1[x]);
            }
            else if(check1==array1[(2*x)+2] && array1[x] < array1[(2*x)+2])
            {
                 swap(array1[(2*x)+2],array1[x]);
            }
            x++;
            if((2*x+1)==size-1)
                return;
        }
    } //END OF DEL FUNCTION

    int gettop()
    {
        return array1[0];
    } // END OF GET TOP FUNCTION

    void isheap()
    {
        int i,x=0;
        int array2[size];
        for(i=0;i<size;i++)
        {
            cout << "ENTER THE VALUE NO " << i << endl;
            cin >> array2[i];
        }
        while(true)
        {
             if(((2*x)+1) > size-1 || ((2*x)+2) > size-1)
    {
                break;
            }

            if(array2[x] >= array2[(2*x)+1] && array2[x] >= array2[(2*x)+2])
            {
                x++;
            }
            else
            {
                cout << "ITS NOT A HEAP" << endl;
                return;
            }

        }
        if(((2*x)+1)<=size-1)
        {
            if(array2[(2*x)+1]<=array2[x])
                cout << "ITS A HEAP" << endl;
                else
                    cout << "its not a heap" << endl;
        }

    }// END OF IS HEAP FUNCTION


}; // END OF CLASS HEAP

int main()
{
    heap obj;
    int a,b;
    int y=0;
    while(y==0)
    {

        cout << "----------------------------------------------" << endl;
        cout << "----------------------------------------------" << endl;
        cout << "TO INSERT SOMETHING IN A HEAP PRESS 1" << endl;
        cout << "TO DISPLAT A HEAP PRESS 2" << endl;
        cout << "TO Delete A value PRESS 3" << endl;
         cout << "TO check the array is heap or not PRESS 4" << endl;
        cin >> a;
        cout << "----------------------------------------------" << endl;
        cout << "----------------------------------------------" << endl;
        if(a==1)
        {
            /*  cout << "ENTER A VALUE YOU WANT TO INSERT" << endl;
              cin >> b;*/
            obj.insert(90);
            obj.insert(80);
            obj.insert(70);
            obj.insert(20);
            obj.insert(77);
            obj.insert(50);
            obj.insert(30);
            obj.insert(5);
            obj.insert(10);
            obj.insert(780);
            cout << "PRESs 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> y;
        }
        if(a==2)
        {
            obj.display1();
            cout << "PRESs 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> y;
        }
        if(a==3)
        {
            obj.del();
              cout << "PRESs 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> y;
        }
        if(a==4)
        {
            obj.isheap();
             cout << "PRESs 0 IF YOU WANT TO CONTINUE" << endl;
            cin >> y;

        }
    }
    return 0;
}
