#include <iostream>
#include<time.h>
#include<stdlib.h>
using namespace std;
int Partition_Random(int *arr,int first,int last)
{
    int pivot=arr[first];
    int x=1;
    for(int y=1;y<=last;y++)
    {
        if(arr[y]<=pivot)
        {
            swap(arr[x],arr[y]);
            x++;
        }
    }
    swap(arr[x-1],arr[first]);
    return x-1;
}
void quickSort_Random(int arr[], int first, int last)
{
    if (first < last)
    {
        srand(time(NULL));
        int r=first+rand()%(last-first);
        swap(arr[first],arr[r]);
        int pivot = Partition_Random(arr, first, last);
        quickSort_Random(arr, first, pivot - 1);
        quickSort_Random(arr, pivot + 1, last);
    }
}

int main()
{
    int n=16;
    int Array[n]={503,87,512,61,908,170,897,275,653,426,154,509,612,677,765,703};
    cout<<"VALUES AFTER RANDOM QUICKSORT:"<<endl;
    quickSort_Random(Array,0,n-1);
    for(int i=0;i<n;i++)
    {
        cout<<Array[i]<<endl;
    }
//    cout << "Hello world!" << endl;
    return 0;
}
