#include <iostream>

using namespace std;
int partition(int *arr,int first,int last)
{
    int pivot=arr[first];
    int x=1;
    for(int y=1;y<=last;y++)
    {
        if(arr[y]<=pivot)
        {
            swap(arr[x],arr[y]);
            x++;
        }
    }
    swap(arr[x-1],arr[first]);
    return x-1;
}
int main()
{

    int i,n=16;
    int Array[n]={503,87,512,61,908,170,897,275,653,426,154,509,612,677,765,703};

    cout<<"ARRAY AFTER PARTITION IS:"<<endl;
     partition(Array,0,n);
    for(i=0;i<n;i++)
    {
        cout<<Array[i]<<endl;
    }

  //  cout << "Hello world!" << endl;
    return 0;
}
