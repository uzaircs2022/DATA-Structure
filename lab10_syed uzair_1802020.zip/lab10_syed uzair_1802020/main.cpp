#include <iostream>

using namespace std;

const int size = 10;
class HASH
{
private:
    int i=0;
    int array[size]= {0};
public:
    int hashfunction(int key)
    {
        return key%size;
    } // END OF FUNCTION

    void insert(int a)
    {
        int check;
        check=(hashfunction(a)+i)%size;
        if(array[check]==0)
        {
            array[check]=a;
        }
        else
        {
            if(i>size)
            {
                cout << " THERE IS NO EMPTY SPACE. SORRY" <<endl;
                return;
            }
            i++;
            insert(a);
        }
        i=0;
    } //    END OF INSERT FUNCTION

    void display()
    {
        for(int i=0; i<size; i++)
        {
            cout << array[i] << endl;
        }

    } // END OF DISPLAY FUNCTION

    void del(int a)
    {
        int check;
        check=(hashfunction(a)+i)%size;
        if(array[check]==a)
        {
            array[check]=0;
        }
        else
        {
            if(i>size)
            {
                cout << " THE NUMBER YOU WANT TO DEL IS NOT PRESENT. SORRY" <<endl;
                return;
            }
            i++;
            del(a);
        }
        i=0;
    } // END OF DEL FUNTION

    void search(int a)
    {
        int check;
        check=(hashfunction(a)+i)%size;
        if(array[check]==a)
        {
            cout << "THE VALUE IS PRESENT IN THE TABLE ANT ITS INDEX IS " << check << endl;
        }
        else
        {
            if(i>size)
            {
                cout << " THE NUMBER YOU WANT TO search IS NOT PRESENT. SORRY" <<endl;
                return;
            }
            i++;
            search(a);
        }
        i=0;
    } // END OF SEARCH FUNCTION

    void fullempty()
    {
        for(int i=0; i<size; i++)
        {
            if(array[i]==0)
            {
                cout << "ARRAY IS NOT FULL" << endl;
                return;
            }
        }
        cout << "LIST IS FULL" << endl;
    } // END OF FULLEMPTY FUNCTION
}; // END OF CLASS HASH

int main()
{
    int choice,check=0;
    HASH obj;
    while (check == 0)
    {
        cout << "------------------------------------------------" << endl;
        cout << "TO INSERT A VALUE PRESS 1" << endl;
        cout << "TO DISPLAY THE VALUES PRESS 2" << endl;
        cout << "TO DELETE THE VALUES PRESS 3" << endl;
        cout << "TO SEARCH THE VALUES PRESS 4" << endl;
        cout << "TO CHECK WEATHER ARRAY IS FULL OR NOT PRESS 5" << endl;
        cin >> choice ;
        cout << "------------------------------------------------" << endl;
        if(choice==1)
        {
            int x;
            cout << "ENTER THE VALUE TO INSERT" << endl;
            cin >> x;
            obj.insert(x);
            cout << "IF YOU WANT TO CONTINUE ENTER 0" << endl;
            cin >> check ;
        }

        if(choice==2)
        {
            obj.display();
            cout << "IF YOU WANT TO CONTINUE ENTER 0" << endl;
            cin >> check ;
        }

        if(choice==3)
        {
            int y;
            cout << "ENTER THE VALUE TO DELETE" << endl;
            cin >> y;
            obj.del(y);
            cout << "IF YOU WANT TO CONTINUE ENTER 0" << endl;
            cin >> check ;
        }

        if(choice==4)
        {
            int y;
            cout << "ENTER THE VALUE TO WANT TO SEARCH" << endl;
            cin >> y;
            obj.search(y);
            cout << "IF YOU WANT TO CONTINUE ENTER 0" << endl;
            cin >> check ;
        }

        if(choice == 5)
        {
            obj.fullempty();
            cout << "IF YOU WANT TO CONTINUE ENTER 0" << endl;
            cin >> check ;
        }

    } //END OF WHILE LOOP
    return 0;
}
