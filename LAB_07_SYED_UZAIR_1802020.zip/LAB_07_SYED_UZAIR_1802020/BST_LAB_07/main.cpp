#include <iostream>

using namespace std;

class node
{
private:
    node*right;
    node*left;
    int data;
public:

    node()
    {
        right = NULL;
        left = NULL;
        data = 0;
    }
    void setright(node*x)
    {
        right=x;
    }
    void setleft(node*y)
    {
        left=y;
    }
    void setdata(int z)
    {
        data=z;
    }
    node* getright()
    {
        return right;
    }
    node* getleft()
    {
        return left;
    }
    int getdata()
    {
        return data;
    }


}; // END OF CLASS node

class BST
{
    node*root;
public:
    BST()
    {
        root=NULL;
    }
    void addavalue(int a)
    {
        node*new1=new node();
        new1->setdata(a);
        node*temp=root;
        if(temp==NULL)
        {
            root=new1;
        }
        else
        {
            while(true)
            {
                if(a<temp->getdata())
                {
                    if(temp->getleft()==NULL)
                    {
                        temp->setleft(new1);
                        return;
                    }
                    else
                        temp=temp->getleft();
                }
                else if(a>=temp->getdata())
                {
                    if(temp->getright()==NULL)
                    {
                        temp->setright(new1);
                        return;
                    }
                    else
                        temp=temp->getright();
                }
            }

        }
    } // END OF ADD_A_VALUE FUNCTION

    void displayr(node*n)
    {
        if(n==NULL)
            return ;
        else
        {
            cout << n->getdata() << endl;
            displayr(n->getleft());
             displayr(n->getright());
        }

    }// END OF INNER display FUNCTION

     void displayr_1(node*n1)
    {
        if (n1 == NULL)
        return;
        else
        {
        displayr_1(n1->getleft());
        cout << n1->getdata() <<endl;
        displayr_1(n1->getright());
        }
    } // END OF IN_ORDER

    void display_2(node*n2)
    {
        if (n2 == NULL)
         return;
    else
    {
     display_2(n2->getleft());
    display_2(n2->getright());
    cout << n2->getdata() << endl;
    }
    } //END OF POST_ORDER


    void display()
    {
         int b;
        cout<< "enter 1 for pre-order" << endl;
        cout << "ENter 2 for in-order" << endl;
        cout << "Enter 3 for post order" << endl;
        cin>>b;
        cout << "-------------------------" << endl;
        if(b==1)
        displayr(root);
        if(b==2)
            displayr_1(root);
        if(b==3)
            display_2(root);
    } // END OF DISPLAY FUNCTION

    void remove1(int b)
    {
        int check=0,check1=0;
        node*temp=new node();
        node*temp2=new node();
        node*temp3=new node();
        node*temp4=new node();
        node*temp5=new node();
        temp=root;
        if(root==NULL)
        {
            cout << "TREE IS EMPTY" << endl;
        }
        else
        {
            while(true)
            {
                if(b==root->getdata())
                {
                    break;
                }
                else if(b<temp->getdata())
                {
                    temp2=temp;
                    temp=temp->getleft();
                    if(temp==NULL)
                    {
                        cout << "Value doesnt Exist" << endl;
                        return;
                    }
                    if(temp->getdata()==b)
                    {
                        check=1;
                        break;
                    }
                }
                else if(b>=temp->getdata())
                {
                    temp3=temp;
                    temp=temp->getright();
                     if(temp==NULL)
                    {
                         cout << "Value doesnt Exist" << endl;
                        return;
                    }
                    if(temp->getdata()==b)
                    {
                        check=2;
                        break;
                    }
                }
            }
            node*temp1=new node();
            temp1=temp;
            if(temp1->getleft()== NULL && temp1->getright()== NULL)
            {
                if(check==1)
                {
                    temp2->setleft(NULL);
                    return;
                }
                else if(check==2)
                {
                    temp3->setright(NULL);
                    return;
                }
            }
            while(temp1->getleft()!= NULL || temp1->getright()!= NULL)
            {
                if(temp->getleft()!=NULL)
                {
                    temp4=temp1;
                    temp1=temp1->getleft();
                     if(temp1->getright()==NULL)
                    {
                        check1=1;
                    }
                    while(temp1->getright()!=NULL)
                    {
                        temp4=temp1;
                        check1=2;
                        temp1=temp1->getright();
                    }
                    temp->setdata(temp1->getdata());
                }
                else if(temp->getright()!=NULL)
                {
                    temp5=temp1;
                    temp1=temp1->getright();
                     if(temp1->getleft()==NULL)
                    {
                        check1=3;
                    }
                    while(temp1->getleft()!=NULL)
                    {
                        temp5=temp1;
                        check1=4;
                        temp1=temp1->getleft();
                    }
                    temp->setdata(temp1->getdata());
                }
                if(temp1->getleft()== NULL && temp1->getright()== NULL)
                {
                    if(check1==1)
                    {
                        temp4->setleft(NULL);
                    }
                    if(check1==2)
                    {
                        temp4->setright(NULL);
                    }
                    if(check1==3)
                    {
                        temp5->setright(NULL);
                    }
                    if(check1==4)
                    {
                        temp5->setleft(NULL);
                    }

                }
                temp=temp1;

            }
        }

    } // END OF REMOVE FUNCTION

    void search1(int z)
    {
        node*temp=new node();
        temp=root;
         if(root==NULL)
        {
            cout << "TREE IS EMPTY" << endl;
        }
         else
        {
            while(true)
            {
                if(z==root->getdata())
                {
                     cout<<"Value Exist"<<endl;
                    break;
                }
                else if(z<temp->getdata())
                {
                    if(temp->getleft()==NULL)
                    {
                        cout<<"Value doesn't Exist"<<endl;
                        break;
                    }
                    temp=temp->getleft();
                    if(temp->getdata()==z)
                    {
                         cout<<"Value Exist"<<endl;
                        break;
                    }
                }
                else if(z>=temp->getdata())
                {
                     if(temp->getright()==NULL)
                    {
                        cout<<"Value doesn't Exist"<<endl;
                        break;
                    }
                    temp=temp->getright();
                    if(temp->getdata()==z)
                    {
                         cout<<"Value Exist"<<endl;
                        break;
                    }
                }
            }

        }

    } // END OF SEARCH VALUE


}; //END OF BST CLASS

int main()
{
    int a,loop=11;
    BST obj;
    while(loop==11)
    {
        cout << "Enter 1 to add a value"<< endl;
        cout << "Enter 2 to DISPLAY the tree"<< endl;
        cout << "Enter 3 to remove a value"<< endl;
        cout << "Enter 4 to search a value"<< endl;
        cin >> a;
        cout << "--------------------------------------- " << endl;
        if(a==1)
        {
           /* int x;
            cout << "ENTER a value to add" << endl;
            cin >> x;*/
            obj.addavalue(10);
             obj.addavalue(19);
              obj.addavalue(7);
               obj.addavalue(21);
                obj.addavalue(39);
                 obj.addavalue(123);
                  obj.addavalue(77);
                   obj.addavalue(2);
                    obj.addavalue(9);
                     obj.addavalue(91);
                      obj.addavalue(80);
                       obj.addavalue(20);
                        obj.addavalue(25);
                         obj.addavalue(27);
                          obj.addavalue(26);
            cout << "--------------------------------------- " << endl;
            cout<< "enter 11 if you want to proceed" << endl;
            cin >> loop;
        } // END OF FIRST OPTION

        if(a==2)
        {
            obj.display();
            cout << "--------------------------------------- " << endl;
            cout<< "enter 11 if you want to proceed" << endl;
            cin >> loop;
        } // END OF 2ND OPTION
        if(a==3)
        {
            int y;
            cout << "ENTER a value to remove" << endl;
            cin >> y;
            obj.remove1(y);
            cout << "--------------------------------------- " << endl;
            cout<< "enter 11 if you want to proceed" << endl;
            cin >> loop;
        } // END OF 3rd OPTION

        if(a==4)
        {
            int z;
            cout << "ENTER a value to search" << endl;
            cin >> z;
            obj.search1(z);
            cout << "--------------------------------------- " << endl;
            cout<< "enter 11 if you want to proceed" << endl;
            cin >> loop;
        } // END OF 4th OPTION
    } // end of main loop
    return 0;
}
