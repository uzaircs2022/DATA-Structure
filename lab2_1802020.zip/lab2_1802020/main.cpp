#include <iostream>
#include <string.h>
#include <stdio.h>
#include <fstream>

using namespace std;

class contact{
private:
    string name;
    string number;
    string email;
    string city;
public:
    void setname(string n)
   {
       name=n;
   }
    void setnumber(string a)
    {
        number=a;
    }
    void setmail(string e)
    {
        email=e;
    }
    void setcity(string c)
    {
        city=c;
    }
    string getname()
    {
        return name;
    }
    string getnumber()
    {
        return number;
    }
    string getmail()
    {
        return email;
    }
    string getcity()
    {
        return city;
    }
//---------------------------------------------------------------

contact()
{
    name = "\0";
    number = "\0";
    email = "\0";
    city = "\0";
}
void setter(string a,string b,string c,string d)
{
    setname(a);
    setnumber(b);
    setmail(c);
    setcity(d);
}

void display()
{
    cout << getname() << endl;
    cout << getnumber() << endl;
    cout << getmail() << endl;
    cout << getcity();
}
};  // end of first class

// second class
class contacts
{
public:
    contact obj[50];
    void addcontact()
    {
        int i;
        string check;
        string name1;
        string number1;
        string email1;
        string city1;
        cout << "enter the name " <<endl;
        cin >> name1;
        cout << "enter the contact number" << endl;
        cin >> number1;
        cout << "enter the email " << endl;
        cin >> email1;
        cout << "enter the city name " << endl;
        cin >> city1;
        for(i=0;i<=50;i++)
        {
           check = obj[i].getname();
            if( check == "\0" )
            {
             obj[i].setter(name1, number1, email1,city1);
             break;
            }

        }
    }   // end of add contact function

void removecontact()
{
    int a,i;
    cout << "enter the index where you want to remove the contact" << endl;
    cin>> a;
    obj[a].setter("\0","\0","\0","\0");
   // obj[a].display();
} // end of remove contact function

void searchcontact()
{
    int i;
    string name2;
  for(i=0;i<=50;i++)
        {
             name2 = obj[i].getname();
            if( name2 == "\0" )
            {
                cout << "Number Of Contacts are " <<endl;
                cout << i << endl;
                    break;
            }
        }
}// end of searchnumber function

void searchperson()
{
    int i;
    string name3,check1;
    cout << " Enter the name of the contact you want to search" << endl;
    cin >> name3;
    for(i=0;i<50;i++)
    {
        check1 = obj[i].getname();
        if(check1 == name3)
        {
            cout << "The information of searched contatc is " << endl;
            obj[i].display();
        }

    }
}// end pf search person function

void displayall()
{
    int i;
    string check2;
    cout << "The information of all contacts are " << endl;
    for(i=0;i<50;i++)
    {
        check2 = obj[i].getname();
        if(check2 != "\0")
        {
            obj[i].display();
            cout<< endl;
            cout << "-----------------------------------------------" << endl;
        }
    }
}// end of display all contacts

void addindex()
{
    int i,num1;
     cout << "Enter the index where you want to add" << endl;
    cin >> num1;
    string check3;
    string name11,name12;
    string number11,number12;
    string email11,email12;
    string city11,city12;
    cout << "enter the name " <<endl;
    cin >> name11;
    cout << "enter the contact number" << endl;
    cin >> number11;
    cout << "enter the email " << endl;
    cin >> email11;
    cout << "enter the city name " << endl;
    cin >> city11;
    check3 = obj[num1].getname();
    if(check3 == "\0")
    {
         obj[num1].setter(name11, number11, email11,city11);
    }
    else
    {
        name12 = obj[num1].getname();
        number12 = obj[num1].getnumber();
        email12 = obj[num1].getmail();
        city12 = obj[num1].getcity();
        for(i=num1+1;i<50;i++)
        {
            check3 = obj[i].getname();
            if(check3 == "\0")
            {
                obj[i].setter(name12,number12,email12,city12);
                obj[num1].setter(name11, number11, email11,city11);
            //  cout << "value of i" << endl;
           //   cout << i;
                break;
            }
        }
    }
} // end of addindex function

void savefile()
{
        int i;
        string check0;
        string name0;
        string number0;
        string email0;
        string city0;
        ofstream file;
         file.open("list.txt");
        for(i=0;i<50;i++)
        {
            check0 = obj[i].getname();
            if(check0 != "\0")
            {
                name0 = obj[i].getname();
                number0 = obj[i].getnumber();
                email0 = obj[i].getmail();
                city0 = obj[i].getcity();
                file<< name0<< endl;
                file<<number0<<endl;
                file<<email0<<endl;
                file<<city0<<endl;
            }
        }
} // end of save file function

void loadfile()
{
    int l=1,i,j;
    ifstream file2;
    string c,check9;
    for(j=0;j<50;j++)
 {
    check9 = obj[j].getname();
        if(check9 == "\0")
        {
            i=j;
            break;
        }
 }
   file2.open("list.txt");

   while(file2.eof()==0)
   {
       file2>>c;
     //  cout << c << endl;
       if(l==1)
       {
           obj[i].setname(c);
       }
       if(l==2)
       {
           obj[i].setnumber(c);
       }
       if(l==3)
       {
           obj[i].setmail(c);
       }
       if(l==4)
       {
           obj[i].setcity(c);
         //  cout <<"the value of i " <<i << endl;
           i++;

       }
       l++;
       if(l==5 )
       {
            l=1;
       }
   }

        obj[i].setter("\0","\0","\0","\0");

   file2.close();


}// end of load file function

}; //end of second class

int main()
{
    int num,a=11;
    contacts o;
    while(a==11)
    {
        cout << "if you want to enter a contact, press 1" << endl;
        cout << "if you to remove a contact, press 2" << endl;
        cout << "if you want to search number of contacts, press 3" << endl;
        cout << "if you want to search a contact, press 4" << endl;
        cout << "if you want to display all contacts, press 5" << endl;
        cout << "if you want to enter a new contact at any index, press 6" << endl;
        cout << "if you want to save contacts to a file, press 7" << endl;
        cout << "if you want to load contacts from file, press 8" << endl;
        cin>> num;
    if (num==1)
        {

        o.addcontact();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
        }// end of first option

    if(num==2)
    {

        o.removecontact();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
    }// end of second option

    if(num==3)
    {
        o.searchcontact();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
    } //end of third option

    if(num==4)
    {
        o.searchperson();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
    } // end of 4th option

    if (num==5)
    {
        o.displayall();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
    } // end of 5th option

   if(num==6)
   {
       o.addindex();
         cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
   } //end of 6th option

   if(num==7)
   {
       o.savefile();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;

   }

   if(num==8)
   {
       o.loadfile();
        cout << endl;
        cout << "---------------------------------------------------"<< endl;
        cout << " if you want to do some other operation, press 11 else 0" << endl;
        cin >> a;
   }

    }// ,aim while loop
    return 0;
}
