#include <iostream>

using namespace std;

class QUEUE
{
private:
    int array1[10]= {0};
    int main=0;
    int main1=0;
    int main2=0;

public:
    void enqueue(int a)
    {
        int i,check;
        for(i=0; i<=9; i++)
        {
            if(array1[i]==0)
            {
                check=1;
            }
        }
        if(check==1)
        {
            array1[main1]=a;
            main1++;
            if(main1==10)
            {
                main1=0;
            }
        }
        else
            cout << "LIST IS FULL" <<endl;
    } // END OF ENQUEUE

    void dequeue()
    {
        int j,check;
        for(j=0; j<=9; j++)
        {
            if(array1[j]!=0)
            {
                check=1;
            }
        }
        if(check==1)
        {
            array1[main]=0;
            main++;
            if (main==10)
            {
                main=0;
            }
        }
        else
        {
            cout<<"List IS empty" << endl;
        }
    }// END OF DEQUEUE

    void display()
    {
        int i;
        for(i=0; i<=9; i++)
        {
            cout << array1[i] << endl;
        }
    } // end of DISPLAY

    void peak()
    {
         int j,check;
        for(j=0; j<=9; j++)
        {
            if(array1[j]!=0)
            {
                check=1;
            }
        }
        if(check==1)
        {
           cout << "THE PEAK VALUE IS " << array1[main] << endl;
            main2++;
            if (main2==10)
            {
                main2=0;
            }
        }
        else
        {
            cout<<"List IS empty" << endl;
        }
    }

    void full()
    {
        if(array1[9]==0)
        {
            cout << "LIST IS NOT FULL" << endl;
        }
        else
        {
            cout << "List is FULL" << endl;
        }
    }
    void clear1()
    {
        int i;
        for(i=10; i>=0; i--)
        {
            array1[i]=0;
        }
    }


}; // END OF CLASS

int main()
{
    int a=0,loop=11;
    QUEUE obj;

    while(loop==11)
    {
        cout << "ENTER 1 for enqueue " <<endl;
        cout << "ENTER 2 for dequeue " <<endl;
        cout << "ENTER 3 to display " <<endl;
        cout << "ENTER 4 to peak value" <<endl;
        cout << "ENTER 5 to check FULL " <<endl;
        cout << "ENTER 6 to clear the queue " <<endl;
        cin >> a;
        cout << "----------------------------" << endl;
        if(a==1)
        {
            int x;
            cout << "ENTER THE VALUE" << endl;
            cin >> x;
            obj.enqueue(x);
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;

        } // end of first option

        if(a==2)
        {
            obj.dequeue();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of 2nd option

        if(a==3)
        {
            obj.display();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of third option

        if(a==4)
        {
            obj.peak();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of forth option

        if(a==5)
        {
            obj.full();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of fifth option

        if(a==6)
        {
            obj.clear1();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of sixth option
    } // main loop

    return 0;

}
