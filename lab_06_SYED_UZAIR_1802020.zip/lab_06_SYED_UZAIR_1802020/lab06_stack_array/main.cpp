
#include <iostream>

using namespace std;

class STACK
{
private:
    int array1[10]= {0};

public:
    void push(int a)
    {
        int main=9;
        while(main>=0)
        {
            if(array1[main]==0)
            {
                array1[main]=a;
                break;
            }
            else
                main--;
        }
    } // END OF ENQUEUE

    void pop()
    {
        int i;
        if(array1[9]==0)
        {
            cout << "List Is Empty " << endl;
        }
        else
        {
            for(i=9; i>=0; i--)
            {
               if(array1[i-1]==0)
               {
                   array1[i]=0;
               }
            }
        }
    }// END OF DEQUEUE

    void display()
    {
        int i;
        for(i=0; i<=9; i++)
        {
            cout << array1[i] << endl;
        }
    } // end of DISPLAY

    void peak()
    {
        if(array1[9]!=0)
        {
            cout << "The Peak Value Is" << array1[9] << endl;
        }
        else
        {
            cout << "QUEUE IS EMPTY" << endl;
        }
    }

    void full()
    {
        if(array1[0]==0)
        {
            cout << "LIST IS NOT FULL" << endl;
        }
        else
        {
            cout << "List is FULL" << endl;
        }
    }
    void clear1()
    {
        int i;
        for(i=10;i>=0;i--)
        {
            array1[i]=0;
        }
    }


}; // END OF CLASS

int main()
{
    int a=0,loop=11;
    STACK obj;

    while(loop==11)
    {
        cout << "ENTER 1 for push " <<endl;
        cout << "ENTER 2 for pop " <<endl;
        cout << "ENTER 3 to display " <<endl;
         cout << "ENTER 4 to peak value" <<endl;
          cout << "ENTER 5 to check FULL " <<endl;
           cout << "ENTER 6 to clear the stack " <<endl;
        cin >> a;
        cout << "----------------------------" << endl;
        if(a==1)
        {
            int x;
            cout << "ENTER THE VALUE" << endl;
            cin >> x;
            obj.push(x);
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;

        } // end of first option

        if(a==2)
        {
            obj.pop();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of 2nd option

        if(a==3)
        {
            obj.display();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of third option

        if(a==4)
        {
            obj.peak();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of forth option

        if(a==5)
        {
            obj.full();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of fifth option

        if(a==6)
        {
            obj.clear1();
            cout << "enter 11 if you want to proceed" << endl;
            cin >> loop;
        }// end of sixth option
    } // main loop

    return 0;
}
