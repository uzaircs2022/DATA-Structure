#include<iostream>
#include<stdio.h>

using namespace std;

int main()
{
	char a[20];
	int i,x=0,j,f=0;
	cout<<"Enter a string" << endl ;
	gets(a);
    for(i=0;*(a+i)!='\0';i++)
    {
        x++;
    }
     cout << "REVERSE ORDER STRING IS" << endl;
    for(j=x;j>=0;j--)
    {
        cout << *(a+j);
        f++;
    }
    cout << endl;
     cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
	return 0;
}
