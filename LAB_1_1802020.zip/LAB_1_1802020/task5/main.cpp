#include<iostream>
#include<stdio.h>

using namespace std;

int main()
{
	char a[50];
	int i,x=0,f=0;
	cout<<"ENTER A STRING" << endl ;
	gets(a);
    for(i=0;*(a+i)!='\0';i++)
    {
        x++;
        f++;
    }
    cout << "the length of the string is " << x << endl;
     cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f ;
	return 0;
}
