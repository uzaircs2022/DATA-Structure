#include <iostream>

using namespace std;

int main()
{
    int num,i,j,count,f=0;
    cout << "ENTER THE VALUE" << endl;
    cin >> num;
    if(num>=2)
    {
        cout << 2 << endl;
    }
    for(i=3;i<num;i++)
    {
        count=0;
      for(j=2;j<i;j++)
          {
              if(i%j==0)
              {
                  count ++;
                 break;
              }
          }
                  if(count==0)
                  cout << i << endl;
                  f++;
      }
      cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}
