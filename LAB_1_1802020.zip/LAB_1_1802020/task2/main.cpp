#include <iostream>

using namespace std;

void reverse_straight(int num)
{
    int i,c=0,a=0,b=1,j,f=0;
    int array[num-1];
    cout << "IN STRAIGHT ORDER" << endl;
    for(i=0;i<num;i++)
      {
      cout << c << endl;
      array[i]=c;
      a=b;
      b=c;
      c=a+b;
 }
 cout << "IN REVERSE ORDER" << endl;
 for(j=num-1;j>=0;j--)
 {
     cout << array[j] << endl;
     f++;
 }
  cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
}
int main()
{
    int num;
    cout << "ENTER THR NUMBER" << endl;
    cin >> num ;
    reverse_straight(num);
    return 0;
}
