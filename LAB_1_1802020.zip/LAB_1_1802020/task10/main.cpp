#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    char static u[7][7];
    string c;
    int j=0,i,x,y,f=0;
   ifstream file2;
   file2.open("grid.txt");

   while(file2.eof()==0)
   {
       file2>>c;
       if(c=="B")
       {
           break;
       }

       if(c!="A")
       {
         for(i=0;i<=8;i++)
         {
             u[j][i]=c[i];
         }
            j++;
       }

       cout<< endl;
   } //main while loop
   int g=0,h=0,z,s,r=0,t=0,q=0;
  for(x=0;x<8;x++)
   {
       for(y=0;y<8;y++)
       {
           if(u[x][y]=='X')
           {
               z=7-x;
               s=7-y;
               for(i=y+1;i<=7;i++)
                {
                    if(u[x][i]=='0')
                    {
                        g++;
                    }
                    if(g==s)
                    {
                        cout<<"X IS REACABLE FROM RIGHt SIDE " <<endl;
                        q=1;
                      //cout <<"1"<<endl;
                      //break;
                    }
                }
                if(q==0)
                {
            for(i=y-1;i>=0;i--)
            {
                if(u[x][i]=='0')
                {
                   h++;
                }
                if(h==y)
                {
                   cout<<"X IS REACABLE FROM LEFT SIDE "<<endl;
                   q=1;
                  //cout <<"2"<<endl;
                      //break;
                }
            }
            }
             if(q==0)
             {
             for(i=x+1;i<=7;i++)
                {
                    if(u[i][y]=='0')
                    {
                        r++;
                    }
                    if(r==z)
                    {
                        cout<<"X IS REACABLE FROM BELOW SIDE "<<endl;
                        q=1;
                      //break;
                    }
                }
             }
             if(q==0)
             {
            for(i=x-1;i>=0;i--)
            {
                if(u[i][y]=='0')
                {
                   t++;
                }
                if(t==x)
                {
                   cout<<"X IS REACABLE FROM UPPER SIDE"<<endl;
                   q=1;
                //out <<"4"<<endl;
                      //break;
                }

            }
             }

              if(q==0)
              {
                  cout << "X IS NOT REACHABLE" << endl;
              }
             //  cout << "THE ROW IS " << x+1;

               //cout << " THE COLUMN IS " << y+1;

           }
       }
       cout<< endl;
       f++;
  }
   cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f << endl;
    return 0;
}
