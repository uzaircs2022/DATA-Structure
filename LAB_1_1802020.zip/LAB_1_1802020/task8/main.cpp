#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

int main()
{
    int num = 0,i=0,f=0;
    char c;
    string check = "stream";
    ifstream file2;
    file2.open("main.cpp");

    while(file2.eof()==0)
    {
       file2>>c;

        if (check[i]==c)
            {
            i++;
            }
            else
            {
                i=0;
            }
        if (i==6)
            {
            num++;
            i=0;
            }
      f++;
   }
   file2.close();
   cout<< "number of stream are " << num << endl;
    cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}
