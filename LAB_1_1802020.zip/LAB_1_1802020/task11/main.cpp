#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

int main()
{
    int num=0,i=0,u=0,y,f=0;
    string c;
    string check = "ali";
    ifstream file2;
    file2.open("grid.txt");

    while(file2.eof()==0)
    {
        y=0,
       file2>>c;
      // cout << c << endl;;
        while(c[y]!='\0')
            {
        if (check[u]==c[y])
            {
            i++;
            u++;
            }
        if (i==3)
            {
            num++;
            i=0;
            u=0;
            }
            y++;
        }
        u=0;
        i=0;
        f++;
   }
   file2.close();
   cout<< "number of ALI word are " << num << endl;
    cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}
