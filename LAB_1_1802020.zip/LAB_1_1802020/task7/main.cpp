#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int i,j,x=0,y=0,f=0;
    char a[20];
    cout << "ENTER A STRING" << endl;
    gets(a);
    for(i=0;*(a+i)!='\0';i++)
    {
        x++;
    }
    for(i=0,j=x-1;i<=x-1,j>=0;i++,j--)
    {
        if(*(a+i)!=*(a+j))
        {
            y++;
        }
        f++;
    }
    if(y==0)
    {
        cout << "THE WORD IS  PALINDROME" << endl;
    }
    else
    {
      cout << "THE WORD IS NOT PALINDROME" << endl;
    }
     cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}
