#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    char static u[7][7];
    string c;
    int j=0,i,x,y,f=0;
   ifstream file2;
   file2.open("grid.txt");

   while(file2.eof()==0)
   {
       file2>>c;
       if(c=="B")
       {
           break;
       }

       if(c!="A")
       {
         for(i=0;i<=8;i++)
         {
             u[j][i]=c[i];
         }
            j++;
       }
            f++;
       cout<< endl;
   } //main while loop
  for(x=0;x<8;x++)
   {
       for(y=0;y<8;y++)
       {
           if(u[x][y]=='X')
           {
               cout << "THE INDEX OF X IS : " << endl;
               cout << "THE ROW IS " << x+1;
               cout << " THE COLUMN IS " << y+1;
           }
       }
       cout<< endl;
  }
   cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}

