#include <iostream>

using namespace std;

int straight(int y,int *c, int *a, int *b, int *x)
{
// int c=0,a=0,b=1,x=0;
    if(*x<y)
    {
      cout <<*c << endl;
      *a=*b;
      *b=*c;
      *c=*a+*b;
    //x++;
      y--;
    }
    straight(y,c,a,b,x);
}

int main()
{
    int c=0,a=0,b=1,x=0;
    int y,u;
    cout << "ENTER A VALUE" << endl;
    cin >> y;
  u=straight(y,&c,&a,&b,&x);
    return 0;
}
