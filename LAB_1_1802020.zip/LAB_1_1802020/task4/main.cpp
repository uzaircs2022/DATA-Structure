#include <iostream>

using namespace std;

void change(int *a, int *b)
{
int c;
c=*a;
*a=*b;
*b=c;
}
int main()
{
    int a,b,f=0;
    cout <<"ENTER FIRST NUMBER" << endl;
    cin >> a;
    cout << "ENTER SECOND NUMBER" << endl;
    cin >> b;
    cout << "BEFORE SWAPPING" << endl;
    cout << "FIRST NUMBER  " << a << endl;
    cout << "SECOND NUMBER  " << b << endl;
    cout << "-----------------------------------"<<endl;
    cout << "AFTER SWAPPING" << endl;
   change(&a,&b);
   cout << "FIRST NUMBER  " << a << endl;
    cout << "SECOND NUMBER  " << b << endl;
    f++;
 cout << "---------------------------------------------" << endl;
      cout << "NUMBER OF STEPS ARE " << f;
    return 0;
}
