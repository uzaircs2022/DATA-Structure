#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>

using namespace std;

class node
{
private:
    int data;
    node *next;
public:
    node()
    {
        data=0;
        next=NULL;
    }
    void setdata(int a)
    {
        data = a;
    }

    void setnext(node* b)
    {
        next = b;
    }
    int getdata()
    {
        return data;
    }
    node* getnext()
    {
        return next;
    }
}; // end of first class

class linkedlist
{

    node*head;
public:
    linkedlist()
    {
        head=NULL;
    }

    void addatend(int a)
    {
        node *n=new node();
        n->setdata(a);
        node *temp=head;
        if(head==NULL)
        {
            head=n;
        }
        else
        {
            while(temp->getnext()!= NULL)
            {
                temp=temp->getnext();
            }
            temp->setnext(n);
        }
    } //end of add at end

    void addatstart(int b)
    {
        node*n=new node();
        n->setdata(b);
        node*temp=head;
        head=n;
        n->setnext(temp);
    }// end of add at start

    void removefromstart()
    {
        if(head==NULL)
        {
            cout << "List Is Empty" << endl;
        }
        else
            head=head->getnext();

    }// end of remove from start

    void removefromend()
    {
        node*temp=new node();
        temp=head;
        if(temp->getnext() == NULL)
        {
            removefromstart();
        }
        else
        {
            while(temp->getnext()->getnext()!= NULL )
            {
                temp=temp->getnext();
            }

            temp->setnext(NULL);

        }
    }// end of remove from end

    void removethevalue(int a)
    {
        node*temp1=new node();
        node*temp2=new node();
        temp1=head;
        temp2=head;
        if(head==NULL)
        {
            cout << "list is empty " << endl;
        }
        else
        {
            if(temp1->getdata()==a)
            {
                removefromstart();
            }
            else
            {
                while(temp1->getdata() != a )
                {

                    temp1=temp1->getnext();

                }
                while(temp2->getnext()->getnext() != temp1->getnext())
                {
                    temp2=temp2->getnext();
                }
                temp2->setnext(temp1->getnext());
            }
        }
    } // end of remove the value

    int getsize()
    {
        int a=0;
        node*temp=new node();
        temp=head;
        while(temp->getnext()!=NULL)
        {
            a++;
            temp=temp->getnext();
        }
        return a+1;
    }// end of get size

    void removeatindex(int a)
    {
        if(head==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            int num=1,x;
            x=getsize();
            if(a>x)
            {
                cout << "Index is not correct" << endl;
            }
            else
            {
                node*temp1=new node();
                node*temp2=new node();
                temp1=head;
                temp2=head;
                if(a==1)
                {
                    removefromstart();
                }
                else
                {
                    while(num<a)
                    {
                        temp1=temp1->getnext();
                        //cout << num << endl;
                        num++;
                    }
                    num=1;
                    while(num<a-1)
                    {
                        temp2=temp2->getnext();
                        // cout << num << endl;
                        num++;
                    }
                    temp2->setnext(temp1->getnext());
                }
            }
        }
    }// end of remove at index

    void addnewvalue(int a, int b)
    {
        node*namal=new node();
        namal=head;
        int num=1;
        int check;
        if(namal==NULL)
        {
            cout << "list is empty value will store in first index" << endl;
            addatstart(a);
        }
        else
        {
            if(b<1)
            {
                addatstart(a);
            }
            else
            {
                //cout << "Enter the value you want to enter" << endl;
                //cin >> val;
                check=getsize();
                if(b>check)
                {
                    b=check+1;
                }
                node*temp1=new node();
                node*temp2=new node();
                node*n=new node();
                n->setdata(a);
                temp1=head;
                temp2=head;
                while(num<b)
                {
                    temp1=temp1->getnext();
                    num++;
                }
                num=1;
                while(num<b-1)
                {
                    temp2=temp2->getnext();
                    num++;
                }
                temp2->setnext(n);
                n->setnext(temp1);

            }
        }
    }// end of new value

    void getvalue(int b)
    {
        int num=1,c;
        node*temp1=new node();
        temp1=head;
        c=getsize();
        if(b>c)
        {
            cout << "This index does not exist" << endl;
        }
        else
        {
            while(num<b)
            {
                temp1=temp1->getnext();
                num++;
            }
            cout << "The value of required Index is " << temp1->getdata() <<endl;;
        }
    } // end of get value

    void searchvalue(int b)
    {
        int num=1,check,check1=0;
        node*temp=new node();
        temp=head;
        check = getsize();
        while(num<=check)
        {
            if(temp->getdata() == b)
            {
                cout << "The index of searched value is " << endl;
                cout << num <<endl;
                check1=1;
                break;
            }
            else
            {
                temp=temp->getnext();
                num++;
            }
        }

        if(check1==0)
        {
            cout << "-1" << endl;
        }
    }// end of search value


    void display()
    {
        node *temp;
        temp=head;
        if(head==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            while(temp->getnext()!= NULL)
            {
                cout << temp->getdata() << endl;
                temp=temp->getnext();
            }
            cout << temp->getdata() << endl;
        }

    }// end of display function

};// end of second class

int main()
{
    int loop=99;
    string c;
    linkedlist l;
    ifstream file2;
    file2.open("check.txt");

    while(file2.eof()==0)
    {
        file2>>c;
        if(c=="A")
        {
            file2>>c;
          stringstream uzi(c);
            int u;
            uzi >> u;
            l.addatend(u);
        } // end of first option

       if(c=="AAS")
        {
            int b;
            file2>>c;
           // cout<<c;
            stringstream uzi(c);
            uzi >> b;
            l.addatstart(b);
        } // end of second option

        if(c=="RFS" || c=="RA")
        {
            l.removefromstart();
        }  // end of third option

        if(c=="RFE")
        {
            l.removefromend();
        } // end of forth option

        if(c=="R")
        {
            int z;
            file2>>c;
            stringstream uzi(c);
            uzi >> z;
            l.removethevalue(z);
        } // end of fifth option


        if(c=="AT")
        {
            int x,y;
            file2>>c;
            stringstream uzi(c);
            uzi >> x;
            file2>>c;
             stringstream uzi1(c);
             uzi1 >> y;
            l.addnewvalue(y,x);
        }// end of 7th option

        if(c=="D")
        {
            l.display();
            cout << "----------------------------------------" << endl;
        } //end of eleventh option
    } // main while loop
    return 0;
}
