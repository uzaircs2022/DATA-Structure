#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

class node
{
private:
    int data;
    node *next;
    node *previous;
public:
    node()
    {
        data=0;
        next=NULL;
        previous=NULL;
    }
    void setdata(int a)
    {
        data = a;
    }

    void setnext(node* b)
    {
        next = b;
    }

    void setprevious(node* c)
    {
        previous = c;
    }
    int getdata()
    {
        return data;
    }
    node* getnext()
    {
        return next;
    }
    node* getprevious()
    {
        return previous;
    }
}; // end of first class

class linkedlist
{

    node*head;
public:
    linkedlist()
    {
        head=NULL;
    }

    void addatend(int a)
    {
        node *n=new node();
        n->setdata(a);
        node *temp=head;
        if(head==NULL)
        {
            head=n;
        }
        else
        {
            while(temp->getnext()!= NULL)
            {
                temp=temp->getnext();
            }
            temp->setnext(n);
            n->setprevious(temp);
        }
    } //end of add at end

    void addatstart(int b)
    {
        node*n=new node();
        n->setdata(b);
        if(head==NULL)
        {
            head=n;
        }
        else
        {
            node*temp=head;
            head=n;
            n->setnext(temp);
            n->getnext()->setprevious(n);
        }
    }// end of add at start

    void removefromstart()
    {
        if(head==NULL)
        {
            cout << "List Is Empty" << endl;
        }
        else if(head->getnext() == NULL)
        {
            head=NULL;
        }
        else
        {
            head=head->getnext();
            head->setprevious(NULL);
        }
    }// end of remove from start

    void removefromend()
    {
        node*temp1=new node();
        node*temp=new node();
        temp=head;
        if(temp==NULL)
        {
            cout << "List is empty " << endl;
        }
        else
        {
            if(temp->getnext() == NULL)
            {
                head=head->getnext();
            }
            else
            {
                if(temp->getnext()->getnext()== NULL)
                {
                    temp->setnext(NULL);
                    temp->setprevious(NULL);
                }
                else
                {
                    while(temp->getnext()->getnext()->getnext()!= NULL )
                    {
                        temp=temp->getnext();
                    }

                    temp->getnext()->setnext(NULL);
                    temp->getnext()->setprevious(temp);
                }
            }
        }
    }// end of remove from end

    void removethevalue(int a)
    {
        node*temp1=new node();
        node*temp2=new node();
        temp1=head;
        temp2=head;
        if(head==NULL)
        {
            cout << "list is empty " << endl;
        }
        else
        {
            if(temp1->getdata()==a)
            {
                removefromstart();
            }
            else
            {
                while(temp1->getnext()->getdata()!= a)
                {
                    temp1=temp1->getnext();
                }
                if(temp1->getnext()->getnext()==NULL)
                {
                    temp2=temp1->getprevious();
                    temp1->getnext()->setprevious(NULL);
                    temp1->setnext(NULL);

                }
                else
                {
                    temp2=temp1->getnext()->getnext();
                    temp1->getnext()->getnext()->setprevious(temp1);
                    temp1->setnext(temp2);
                }
            }
        }
    } // end of remove the value

    int getsize()
    {
        int a=0;
        node*temp=new node();
        temp=head;
        while(temp->getnext()!=NULL)
        {
            a++;
            temp=temp->getnext();
        }
        return a+1;
    }// end of get size

    void removeatindex(int a)
    {
        if(head==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            int num=1,x;
            x=getsize();
            if(a>x)
            {
                cout << "Index is not correct" << endl;
            }
            else
            {
                node*temp1=new node();
                node*temp2=new node();
                temp1=head;
                temp2=head;
                if(a==1)
                {
                    removefromstart();
                }
                else
                {
                    while(num<a)
                    {
                        temp1=temp1->getnext();
                        // cout << num << endl;
                        num++;
                    }
                    // cout << num << endl;
                    num=1;
                    while(num<a-1)
                    {
                        temp2=temp2->getnext();
                        // cout << num << endl;
                        num++;
                    }
                    temp2->setnext(temp1->getnext());
                    temp1->setprevious(NULL);
                    if(temp1->getnext()!= NULL)
                    {
                        temp1->getnext()->setprevious(temp2);
                        temp1->setnext(NULL);
                    }

                }
            }
        }
    }// end of remove at index

    void addnewvalue(int a, int b)
    {
        node*namal=new node();
        namal=head;
        int num=1;
        int check;
        if(namal==NULL)
        {
            cout << "list is empty value will store in first index" << endl;
            addatstart(a);
        }
        else
        {
            if(b<=1)
            {
                addatstart(a);
            }
            else
            {
                //cout << "Enter the value you want to enter" << endl;
                //cin >> val;
                check=getsize();
                if(b>check)
                {
                    addatend(a);
                }
                else
                {
                    node*temp1=new node();
                    node*temp2=new node();
                    node*n=new node();
                    n->setdata(a);
                    temp1=head;
                    temp2=head;
                    while(num<b)
                    {
                        temp1=temp1->getnext();
                        num++;
                    }
                    num=1;
                    while(num<b-1)
                    {
                        temp2=temp2->getnext();
                        num++;
                    }
                    temp2->setnext(n);
                    n->setprevious(temp2);
                    n->setnext(temp1);
                    temp1->setprevious(n);
                    // cout << n->getprevious()->getdata() <<endl;
                }

            }
        }
    }// end of new value

    void getvalue(int b)
    {
        int num=1,c;
        node*temp1=new node();
        temp1=head;
        c=getsize();
        if(b>c)
        {
            cout << "This index does not exist" << endl;
        }
        else
        {
            while(num<b)
            {
                temp1=temp1->getnext();
                num++;
            }
            cout << "The value of required Index is " << temp1->getdata() <<endl;;
        }
    } // end of get value

    void searchvalue(int b)
    {
        int num=1,check,check1=0;
        node*temp=new node();
        temp=head;
        check = getsize();
        while(num<=check)
        {
            if(temp->getdata() == b)
            {
                cout << "The index of searched value is " << endl;
                cout << num <<endl;
                check1=1;
                break;
            }
            else
            {
                temp=temp->getnext();
                num++;
            }
        }

        if(check1==0)
        {
            cout << "-1" << endl;
        }
    }// end of search value


    void display()
    {
        node *temp;
        temp=head;
        if(head==NULL)
        {
            cout << "List is empty" << endl;
        }
        else
        {
            while(temp->getnext()!= NULL)
            {
                cout << temp->getdata() << endl;
                temp=temp->getnext();
            }
            cout << temp->getdata() << endl;
        }

    }// end of display function

     void disp1()
    {
        if(head==NULL)
        {
            cout << "Queue is empty" << endl;
        }
        else
        {
        cout << "First Value is " << endl;
        cout << head->getdata() << endl;
    }
    } // end of disp1 function

    void dispend()
    {
       node*temp;
       temp=head;
       if(head==NULL)
       {
        cout << "Queue is empty" << endl;
       }
       else
       {
           while(temp->getnext()!=NULL)
           {
               temp=temp->getnext();
           }
           cout << "THE last value is" << endl;
           cout << temp->getdata();
       }
    } // end of dispend function

    void reversequeue()
    {
        node*temp;
        node*temp1;
        node*temp2;
        node*temp3;
        temp=head;
        if(head==NULL)
        {
            cout << "list is empty" << endl;
        }
        else
        {
        while(temp->getnext()!=NULL)
        {
         temp=temp->getnext();
        }

        head=temp;
        temp1=temp;
        while(temp1->getprevious()!=NULL)
        {
            temp1->setnext(temp1->getprevious());
            temp1=temp1->getprevious();
        }
        temp1->setnext(temp1->getprevious());

        temp2=head;
        temp2->setprevious(NULL);
        while(temp2->getnext()->getnext()!=NULL)
        {
            temp3=temp2->getnext();
            temp3->setprevious(temp2);
            temp2=temp2->getnext();
        }

       temp3=temp2->getnext();
       temp3->setprevious(temp2);
       temp2->getnext()->setnext(NULL);
        }
    }// end of reverse queue

};// end of second class

class QUEUE
{
private:
    linkedlist o;
public:
    void enqueue(int a)
    {
        o.addatend(a);
    } // end of enqueue function

    void dequeue()
    {
        o.removefromstart();
    } // end of dequeue function

    void frontfunction()
    {
       o.disp1();
    } // end of front function

    void backfunction()
    {
        o.dispend();
    } // end of back function

    void displayqueue()
    {
        o.display();
    } // end of display function

    void queuesize()
    {
        int a;
        a=o.getsize();
        cout << "THE SIZE OF QUEUE IS " << a <<endl;
    } // end of queue size function

    void findqueue(int b)
    {
        o.searchvalue(b);
    } //end of find queue function

    void queuereverse()
    {
        o.reversequeue();
    }//reverse of queue reverse

}; //end of third class

int main()
{
    int a,loop=99;
    QUEUE q;

    while(loop==99)
    {
        cout << "Enter 1 for enqueue" << endl;
        cout << "Enter 2 for dequeue" << endl;
        cout << "Enter 3 to display peak value" << endl;
        cout << "Enter 4 to display last value" << endl;
        cout << "Enter 5 to display the queue" << endl;
        cout << "Enter 6 to to get size of queue" << endl;
        cout << "Enter 7 to search index of value in queue" << endl;
        cout << "Enter 8 to reverse the queue" << endl;
        cout << "enter the value" << endl;
        cin >> a;
        cout << "----------------------------------" << endl;
        if(a==1)
        {
            int u;
            cout << "Enter the value you want to add " << endl;
            cin >> u;
            q.enqueue(u);
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        } // end of first option

        if(a==2)
        {
           q.dequeue();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        } // end of second option

        if(a==3)
        {
            q.frontfunction();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        }  // end of third option

        if(a==4)
        {
            q.backfunction();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        } // end of forth option

        if(a==5)
        {
           q.displayqueue();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        } // end of fifth option

        if(a==6)
        {
            q.queuesize();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        } //end of seth option

        if(a==7)
        {
            int x;
            cout << " Enter the value you want to search" << endl;
            cin >> x;
            q.findqueue(x);
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;
        }// end of 7th option

       if(a==8)
        {
            q.queuereverse();
            cout << "----------------------------------" << endl;
            cout << "Enter 99 if you want to proceed" << endl;
            cin >> loop;

        }// end of eight option

    } // main while loop
    return 0;
}
